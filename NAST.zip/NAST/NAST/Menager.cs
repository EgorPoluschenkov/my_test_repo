﻿using NAST.AddDate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace NAST
{
    internal class Manager
    {
        // Добавляем это
        public static Frame Fram { get; set; }
    }

    public class AppDate1
    {
        public static Hospital1Entities1 Sqlconn = new Hospital1Entities1();
    }
}