﻿using NAST.Pag.PageGeneral_information.PagElements;
using NAST.Pag.PageGeneral_information;
using NAST.Pag.PDateMedCard;
using NAST.Pag.PDateMedCard_TalonExport;
using NAST.Pag;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Navigation;

namespace NAST
{
    public partial class MainWindow : Window
    {
        private Button previousButton; // Предыдущая нажатая кнопка

        public MainWindow()
        {
            InitializeComponent();
            Fram.Navigate(new PageLogin());
            Manager.Fram = Fram;
            Fram.Navigated += Fram_Navigated;

            PatientIdTextBox.TextChanged += PatientIdTextBox_TextChanged;
            PatientIdTextBox.TextChanged += PageMedical_history_TextChanged;

            // Добавляем обработчик события Click для каждой кнопки
            BtTours.Click += Button_Click;
            BtHotels.Click += Button_Click;
            BtMed_cart.Click += Button_Click;
            BtInform.Click += Button_Click;
            BtTalon.Click += Button_Click;
            BtArchive.Click += Button_Click;
            BtnBackGeneral.Click += BtnBackGenera_Click;
            
        }

        // Обработчик события Click для кнопок
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;

            // Если есть предыдущая нажатая кнопка, возвращаем ее цвет к исходному состоянию
            if (previousButton != null)
            {
                previousButton.Background = Brushes.Transparent;
            }

            // Изменяем цвет текущей кнопки на светло-серый
            button.Background = Brushes.LightGray;

            previousButton = button; // Сохраняем текущую кнопку как предыдущую
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.Fram.GoBack();
        }

        private void MainFrame_ContentRendered(object sender, EventArgs e)
        {
            if (Fram.CanGoBack)
            {
                BtnBack.Visibility = Visibility.Visible;
            }
            else
            {
                BtnBack.Visibility = Visibility.Hidden;
            }
        }

        private void PatientIdTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Fram.Content is PageDateMedCard pageDateMedCard)
            {
                pageDateMedCard.LoadData();
            }
        }

        private void Fram_Navigated(object sender, NavigationEventArgs e)
        {
            // Проверяем тип содержимого страницы
            if (Fram.Content is PageDateMedCard || Fram.Content is PageMedical_history || Fram.Content is PageTalon || Fram.Content is PageArchive || Fram.Content is PageGeneral)
            {
                ShowCommonElements();
            }
            else if (Fram.Content is PageStatistics)
            {
                ShowCommonElement();
                BtnBackGeneral.Visibility = Visibility.Visible;
            }
            else if (Fram.Content is PageStatistics)
            {
                HideAllElements();
            }
            else
            {
                HideAllElements();
            }
        }

        private void ShowCommonElements()
        {
            BtTours.Visibility = Visibility.Visible;
            BtHotels.Visibility = Visibility.Visible;
            BtMed_cart.Visibility = Visibility.Visible;
            BtInform.Visibility = Visibility.Visible;
            LbID.Visibility = Visibility.Visible;
            PatientIdTextBox.Visibility = Visibility.Visible;
            BtTalon.Visibility = Visibility.Visible;
            BtArchive.Visibility = Visibility.Visible;
        }
        private void ShowCommonElement()
        {
            BtTours.Visibility = Visibility.Collapsed;
            BtHotels.Visibility = Visibility.Collapsed;
            BtMed_cart.Visibility = Visibility.Collapsed;
            BtInform.Visibility = Visibility.Collapsed;
            LbID.Visibility = Visibility.Visible;
            PatientIdTextBox.Visibility = Visibility.Visible;
            BtTalon.Visibility = Visibility.Collapsed;
            BtArchive.Visibility = Visibility.Collapsed;
        }

        private void HideAllElements()
        {
            BtTours.Visibility = Visibility.Collapsed;
            BtHotels.Visibility = Visibility.Collapsed;
            BtMed_cart.Visibility = Visibility.Collapsed;
            BtInform.Visibility = Visibility.Collapsed;
            LbID.Visibility = Visibility.Collapsed;
            PatientIdTextBox.Visibility = Visibility.Collapsed;
            BtTalon.Visibility = Visibility.Collapsed;
            BtArchive.Visibility = Visibility.Collapsed;
            BtnBackGeneral.Visibility = Visibility.Collapsed;
        }

        private void PageMedical_history_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Fram.Content is PageMedical_history pageDateMedCard)
            {
                pageDateMedCard.LoadData();
            }
        }

        private void BtTours_Click(object sender, RoutedEventArgs e)
        {
            Manager.Fram.Navigate(new PageMedical_history((MainWindow)Window.GetWindow(this)));
        }

        private void BtMed_cart_Click(object sender, RoutedEventArgs e)
        {
            Manager.Fram.Navigate(new PageDateMedCard((MainWindow)Window.GetWindow(this)));
        }

        private void BtTalon_Click(object sender, RoutedEventArgs e)
        {
            Manager.Fram.Navigate(new PageTalon((MainWindow)Window.GetWindow(this)));
        }

        private void BtArchive_Click(object sender, RoutedEventArgs e)
        {
            Manager.Fram.Navigate(new PageArchive((MainWindow)Window.GetWindow(this)));
        }

        private void BtnBackGenera_Click(object sender, RoutedEventArgs e)
        {
            Manager.Fram.Navigate(new PageGeneral());
        }
        private void BtInform_Click(object sender, RoutedEventArgs e)
        {
            Manager.Fram.Navigate(new PageGeneral());
        }
    }
}