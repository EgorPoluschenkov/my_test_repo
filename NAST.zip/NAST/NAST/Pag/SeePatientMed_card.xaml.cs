﻿using System;
using System.Windows;
using System.Windows.Controls;
using NAST.AddDate;
using static NAST.Pag.PageDateMedCard;

namespace NAST.Pag
{
    public partial class SeePatientMed_card : Page
    {
        public SeePatientMed_card(MedicalCardViewModel medicalCardViewModel, int patientID)
        {
            InitializeComponent();

            // Присваиваем объект medicalCardViewModel в качестве DataContext для страницы
            DataContext = medicalCardViewModel;
        }
    }
}