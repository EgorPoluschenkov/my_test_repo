﻿using Microsoft.Win32;
using System.Windows.Controls.DataVisualization.Charting;
using NAST.AddDate;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

namespace NAST.Pag.PageGeneral_information.PagElements
{
    public partial class PageStatistics : Page
    {
        private Hospital1Entities1 db;
        private MainWindow mainWindow;

        public PageStatistics(MainWindow mainWindow)
        {
            InitializeComponent();

            // Создаем экземпляр контекста базы данных
            db = new Hospital1Entities1();
            this.mainWindow = mainWindow;
            FillCbWan(); // заполняем первый комбобокс
        }

        private void FillCbWan()
        {
            // Заполнение первого комбобокса
            CbWan.Items.Add("Анализы");
            CbWan.Items.Add("Посещение");
        }

        private void CbWan_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Обработчик изменения выбора в первом комбобоксе
            if (CbWan.SelectedItem != null && CbWan.SelectedItem.ToString() == "Анализы")
            {
                FillCbTo(); // Если выбраны анализы, заполняем второй комбобокс
            }
            else
            {
                CbTo.Items.Clear(); // Очищаем второй комбобокс
            }
        }

        private void FillCbTo()
        {
            // Очищаем предыдущие элементы в комбобоксе
            CbTo.Items.Clear();

            try
            {
                var query = @"SELECT COLUMN_NAME
                                FROM INFORMATION_SCHEMA.COLUMNS
                                WHERE TABLE_NAME = 'Analysis'
                                AND COLUMN_NAME IN ('Total_protein', 'High_Density_lipoprotein_cholesterol', 'Glucose', 'Testosterone');";

                using (var command = new SqlCommand(query, (SqlConnection)db.Database.Connection))
                {
                    db.Database.Connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string analysisName = reader.GetString(0);
                            CbTo.Items.Add(analysisName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при заполнении списка анализов: {ex.Message}");
            }
            finally
            {
                db.Database.Connection.Close();
            }
        }

        private void FetchDataForGraph(int patientId, string columnName)
        {
            try
            {
                db.Database.Connection.Open();
                var query = $@"SELECT A.Date_time, A.{columnName}
                            FROM Analysis A
                            INNER JOIN Diagnostic_Diagnosis DD ON A.Diagnostic_Diagnosis_id = DD.ID
                            INNER JOIN Patient_Diagnosis PD ON DD.Diagnosis_id = PD.Diagnosis_id
                            WHERE PD.Patient_id = @PatientId";

                using (var command = new SqlCommand(query, (SqlConnection)db.Database.Connection))
                {
                    command.Parameters.AddWithValue("@PatientId", patientId);
                    using (var reader = command.ExecuteReader())
                    {
                        var data = new List<KeyValuePair<DateTime, double>>();
                        while (reader.Read())
                        {
                            DateTime dateTime = reader.GetDateTime(0).Date;
                            string valueString = reader.GetString(1);
                            double value;
                            if (double.TryParse(valueString, out value))
                            {
                                data.Add(new KeyValuePair<DateTime, double>(dateTime, value));
                            }
                            else
                            {
                                string errorMessage = $"Ошибка преобразования значения '{valueString}' в тип double";
                                lbResult.Content = errorMessage;
                                MessageBox.Show(errorMessage);
                                return;
                            }
                        }

                        // Построение графика
                        Chart.Series.Clear();
                        var lineSeries = new LineSeries();
                        lineSeries.ItemsSource = data;
                        lineSeries.DependentValuePath = "Value";
                        lineSeries.IndependentValuePath = "Key";
                        Chart.Series.Add(lineSeries);

                        // Отображение информации в lbResult
                        if (data.Any())
                        {
                            lbResult.Content = $"Анализы: {columnName}\n";
                            foreach (var item in data)
                            {
                                lbResult.Content += $"{item.Key.ToShortDateString()} - Показатель {item.Value}\n";
                            }
                        }
                        else
                        {
                            lbResult.Content = "Нет данных для отображения.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string errorMessage = $"Ошибка при выполнении запроса: {ex.Message}";
                lbResult.Content = errorMessage;
                MessageBox.Show(errorMessage);
            }
            finally
            {
                db.Database.Connection.Close();
            }
        }

        private void BtStart_Click(object sender, RoutedEventArgs e)
        {
            if (mainWindow.PatientIdTextBox != null && !string.IsNullOrWhiteSpace(mainWindow.PatientIdTextBox.Text))
            {
                int patientId;
                if (int.TryParse(mainWindow.PatientIdTextBox.Text, out patientId))
                {
                    if (CbTo.SelectedItem != null)
                    {
                        string columnName = CbTo.SelectedItem.ToString();
                        FetchDataForGraph(patientId, columnName);
                    }
                    else
                    {
                        MessageBox.Show("Выберите параметр для построения графика");
                    }
                }
                else
                {
                    MessageBox.Show("Введите корректный идентификатор пациента");
                }
            }
            else
            {
                MessageBox.Show("Введите идентификатор пациента");
            }
        }
        private void BtSave_Click(object sender, RoutedEventArgs e)
        {
           
        }
    }
}