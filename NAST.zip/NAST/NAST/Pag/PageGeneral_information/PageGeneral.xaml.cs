﻿using NAST.AddDate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using NAST.Pag.PageGeneral_information.PagElements;

namespace NAST.Pag.PageGeneral_information
{
    /// <summary>
    /// Логика взаимодействия для PageGeneral.xaml
    /// </summary>
    public partial class PageGeneral : Page
    {
        public PageGeneral()
        {
            InitializeComponent();
        }

        private void btStatistics_Click(object sender, RoutedEventArgs e)
        {
            // Передаем экземпляр MainWindow в конструктор PageStatistics
            Manager.Fram.Navigate(new PageStatistics((MainWindow)Window.GetWindow(this)));
        }
    }
}