﻿using NAST.AddDate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NAST.Pag
{
    /// <summary>
    /// Логика взаимодействия для PageDateMedCard.xaml
    /// </summary>
    public partial class PageDateMedCard : Page
    {
        private Hospital1Entities1 db;
        List<MedicalCardViewModel> result;
        private MainWindow mainWindow;
        public PageDateMedCard(MainWindow mainWindow)
        {
            InitializeComponent();
            db = new Hospital1Entities1();
            this.mainWindow = mainWindow;
            LoadData();
        }
        public class MedicalCardViewModel
        {
            public int PatientID { get; set; }
            public string PatientName { get; set; }
            public string PatientLastName { get; set; }
            public string Diagnosis_name { get; set; }
            public int Medical_card_number { get; set; }
            public DateTime Date_of_issue { get; set; }
            public DateTime Date_of_last_request { get; set; }
            public string ErrorMessage { get; set; }
        }
        public void LoadData()
        {
            if (int.TryParse(mainWindow.PatientIdTextBox.Text, out int patientId))
            {
                result = db.Database.SqlQuery<MedicalCardViewModel>($"SELECT P.ID as PatientID," +
                                                                     "P.[Name] as PatientName," +
                                                                     "P.Last_Name as PatientLastName," +
                                                                     "D.Diagnosis_name," +
                                                                     "M.Medical_card_number," +
                                                                     "M.Date_of_issue," +
                                                                     "M.Date_of_last_request " +
                                                                     "FROM Patient P " +
                                                                     "JOIN Medical_card M ON P.Medical_card_number_id = M.Medical_card_number " +
                                                                     "LEFT JOIN Diagnosis D ON D.ID = (" +
                                                                     "SELECT TOP 1 HD.Diagnosis_id " +
                                                                     "FROM Medical_card MC " +
                                                                     "JOIN Hospitalizations H ON MC.Medical_card_number = H.ID " +
                                                                     "JOIN Hospitalizations_Diagnosis HD ON H.ID = HD.Hospitalizations_id " +
                                                                     "WHERE MC.Medical_card_number = P.Medical_card_number_id " +
                                                                     "ORDER BY H.Date_of_discharge DESC) " +
                                                                     $"WHERE P.ID = {patientId}")
                            .ToList();

                // Проверка наличия данных в результате запроса
                if (result.Any())
                {
                    DGridTour.Visibility = Visibility.Visible;
                    DGridTour.ItemsSource = result;

                    // Скрываем TextBlock
                    ErrorMessageTextBlock.Visibility = Visibility.Collapsed;
                }
                else
                {
                    // Если результат пуст, создайте экземпляр MedicalCardViewModel с сообщением об ошибке
                    result = new List<MedicalCardViewModel>
                    {
                        new MedicalCardViewModel
                        {
                            ErrorMessage = "Введите идентификатор"
                        }
                    };

                    DGridTour.Visibility = Visibility.Collapsed;
                    DGridTour.ItemsSource = result;

                    // Отображаем TextBlock
                    ErrorMessageTextBlock.Visibility = Visibility.Visible;
                }
            }
            else
            {
                // Если patientId равен NULL, создайте экземпляр MedicalCardViewModel с сообщением об ошибке
                result = new List<MedicalCardViewModel>
                {
                    new MedicalCardViewModel
                    {
                        ErrorMessage = "Введите идентификатор"
                    }
                };

                DGridTour.Visibility = Visibility.Collapsed;
                DGridTour.ItemsSource = result;

                // Отображаем TextBlock
                ErrorMessageTextBlock.Visibility = Visibility.Visible;
            }
        }
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedPatient = (sender as Button).DataContext as MedicalCardViewModel;
            Manager.Fram.Navigate(new SeePatientMed_card(selectedPatient, selectedPatient.PatientID));

        }
    }
}
