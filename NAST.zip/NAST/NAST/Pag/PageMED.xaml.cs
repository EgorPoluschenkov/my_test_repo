﻿using NAST.AddDate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;


namespace NAST.Pag
{
    public partial class PageMED : Page
    {
        private Hospital1Entities1 db;

        public PageMED()
        {
            InitializeComponent();
            db = new Hospital1Entities1();
            LoadData();
        }

        private void LoadData()
        {
            var patients = db.Patient.ToList(); // Предполагается, что сущность называется Patients
            DGridTour.ItemsSource = patients;
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            int idValue;
            var id = string.IsNullOrEmpty(TxtId.Text) || TxtId.Text == "Введите идентификатор" || !int.TryParse(TxtId.Text, out idValue) ? null : (int?)idValue;

            var name = string.IsNullOrEmpty(TxtName.Text) || TxtName.Text == "Введите имя" ? null : TxtName.Text;

            var Phone_number = string.IsNullOrEmpty(TxtPhone_number.Text) || TxtPhone_number.Text == "Введите номер телефона" ? null : TxtPhone_number.Text;

            var patients = db.Patient.ToList();
            if (id != null)
                patients = patients.Where(p => p.ID == id).ToList();
            if (!string.IsNullOrEmpty(name))
                patients = patients.Where(p => p.Name == name).ToList();
            if (!string.IsNullOrEmpty(Phone_number))
                patients = patients.Where(p => p.Phone_number == Phone_number).ToList();

            DGridTour.ItemsSource = patients;
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            tb.Text = string.Empty;
            tb.GotFocus -= TextBox_GotFocus;
        }

        private void Toggle_Click(object sender, RoutedEventArgs e)
        {
            SearchPanel.Visibility = SearchPanel.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        }
    }
}