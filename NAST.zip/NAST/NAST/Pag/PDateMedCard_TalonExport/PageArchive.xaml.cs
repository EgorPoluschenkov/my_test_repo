﻿using NAST.AddDate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using System.Reflection;
using System.IO;
using Microsoft.Win32;
using System.Data;

namespace NAST.Pag.PDateMedCard_TalonExport
{
    /// <summary>
    /// Логика взаимодействия для PageArchive.xaml
    /// </summary>
    public partial class PageArchive : Page
    {
        private Hospital1Entities1 db;
        List<PagePageArchiveViewModel> result;
        private MainWindow mainWindow;
        public PageArchive(MainWindow mainWindow)
        {
            InitializeComponent();
            db = new Hospital1Entities1();
            this.mainWindow = mainWindow;
            LoadData();
        }
        public class PagePageArchiveViewModel
        {
            public int ArchiveID { get; set; }
            public string Archive_Type { get; set; }
            public string Archive_Object { get; set; }
            public string ErrorMessage { get; set; }

        }
        public void LoadData()
        {
            if (int.TryParse(mainWindow.PatientIdTextBox.Text, out int patientId))
            {
                result = db.Database.SqlQuery<PagePageArchiveViewModel>($@"SELECT p.ID,
		                                                                        p.Archive_Type,
		                                                                        p.Archive_Object
                                                                                FROM Archive p
                                                                                WHERE Patient_id = {patientId}")
                                                                                    .ToList();

                // Проверка наличия данных в результате запроса
                if (result.Any())
                {
                    DGridTour.Visibility = Visibility.Visible;
                    BtnSearch.Visibility = Visibility.Visible;
                    DGridTour.ItemsSource = result;

                    // Скрываем TextBlock
                    ErrorMessageTextBlock.Visibility = Visibility.Collapsed;
                }
                else
                {
                    // Если результат пуст, создайте экземпляр MedicalCardViewModel с сообщением об ошибке
                    result = new List<PagePageArchiveViewModel>
                    {
                        new PagePageArchiveViewModel
                        {
                            ErrorMessage = "Введите идентификатор"
                        }
                    };

                    DGridTour.Visibility = Visibility.Collapsed;
                    BtnSearch.Visibility = Visibility.Collapsed;
                    DGridTour.ItemsSource = result;

                    // Отображаем TextBlock
                    ErrorMessageTextBlock.Visibility = Visibility.Visible;
                }
            }
            else
            {
                // Если patientId равен NULL, создайте экземпляр MedicalCardViewModel с сообщением об ошибке
                result = new List<PagePageArchiveViewModel>
                {
                    new PagePageArchiveViewModel
                    {
                        ErrorMessage = "Введите идентификатор"
                    }
                };

                DGridTour.Visibility = Visibility.Collapsed;
                DGridTour.ItemsSource = result;

                // Отображаем TextBlock
                ErrorMessageTextBlock.Visibility = Visibility.Visible;
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {

            var tType_Archive = string.IsNullOrEmpty(TxtType_Archive.Text) || TxtType_Archive.Text == "Введите номер телефона" ? null : TxtType_Archive.Text;

            var patients = db.Archive.ToList();

            if (!string.IsNullOrEmpty(tType_Archive))
                patients = patients.Where(p => p.Archive_Type == tType_Archive).ToList();

            DGridTour.ItemsSource = patients;
        }
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            tb.Text = string.Empty;
            tb.GotFocus -= TextBox_GotFocus;
        }

        private void Toggle_Click(object sender, RoutedEventArgs e)
        {
            SearchPanel.Visibility = SearchPanel.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        }

        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            // Получаем выбранный элемент из DataGrid
            var selectedItem = (PagePageArchiveViewModel)DGridTour.SelectedItem;

            // Создаем объект типа DataTable
            DataTable dt = new DataTable("Archive");

            // Добавляем столбцы в таблицу
            dt.Columns.Add("Archive_Type", typeof(string));
            dt.Columns.Add("Archive_Object", typeof(string));

            // Добавляем данные в таблицу
            dt.Rows.Add(selectedItem.Archive_Type, selectedItem.Archive_Object);

            // Создаем объект типа SaveFileDialog
            SaveFileDialog saveFileDialog = new SaveFileDialog();

            // Устанавливаем фильтр для сохранения файлов
            saveFileDialog.Filter = "Excel Files (*.xls)|*.xls";

            // Устанавливаем заголовок диалогового окна
            saveFileDialog.Title = "Экспорт данных в Excel";

            // Отображаем диалоговое окно
            if (saveFileDialog.ShowDialog() == true)
            {
                // Получаем путь к файлу
                string filename = saveFileDialog.FileName;

                // Экспортируем данные в файл Excel
                using (StreamWriter sw = new StreamWriter(filename, false, Encoding.UTF8))
                {
                    // Записываем заголовки столбцов в файл
                    foreach (DataColumn column in dt.Columns)
                    {
                        sw.Write(column.ColumnName + "\t");
                    }

                    sw.WriteLine();

                    // Записываем данные в файл
                    foreach (DataRow row in dt.Rows)
                    {
                        foreach (DataColumn column in dt.Columns)
                        {
                            sw.Write(row[column] + "\t");
                        }

                        sw.WriteLine();
                    }
                }

                // Отображаем сообщение об успешном экспорте
                MessageBox.Show("Данные успешно экспортированы в файл Excel", "Экспорт данных", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
