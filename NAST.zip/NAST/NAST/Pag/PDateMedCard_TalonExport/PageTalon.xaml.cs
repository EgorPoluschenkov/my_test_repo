﻿using NAST.AddDate;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace NAST.Pag.PDateMedCard_TalonExport
{
    /// <summary>
    /// Логика взаимодействия для PageTalon.xaml
    /// </summary>
    public partial class PageTalon : Page
    {
        private Hospital1Entities1 db;
        private MainWindow mainWindow;
        private Patient patient;
        private int selectedDoctorId;

        public PageTalon(MainWindow mainWindow)
        {
            InitializeComponent();

            this.mainWindow = mainWindow;
            db = new Hospital1Entities1();

            var specializations = db.Doctor.Select(d => d.Specialization).Distinct().ToList();
            SpecializationCB.ItemsSource = specializations;
            SpecializationCB.SelectionChanged += SpecializationCB_SelectionChanged;
            signupButton.Click += SignupButton_Click;
            DoctorCB.SelectionChanged += DoctorCB_SelectionChanged;
            DateCB.SelectedDateChanged += DateCB_SelectedDateChanged;
        }

        private void DoctorCB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedDoctorName = (string)DoctorCB.SelectedItem;
            var selectedDoctor = db.Doctor.FirstOrDefault(d => (d.Surname + " " + d.Name + " " + d.Middle_name) == selectedDoctorName);
            if (selectedDoctor != null)
            {
                selectedDoctorId = selectedDoctor.ID;
                FillTimeComboBox();
            }
        }

        private void DateCB_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            FillTimeComboBox();
        }

        private void FillTimeComboBox()
        {
            if (DoctorCB.SelectedItem == null || DateCB.SelectedDate == null)
            {
                TimeCB.ItemsSource = null;
            }
            else
            {
                DateTime selectedDate = DateCB.SelectedDate.Value.Date;

                // Fetch the times of existing records for this doctor on the selected date
                var recordedTimes = db.Record.Where(r => r.Doctor_id == selectedDoctorId && DbFunctions.TruncateTime(r.Date_reception) == selectedDate)
                                             .Select(r => r.Time_of_acceptance)
                                             .ToList();

                var quarterHourTimes = new ObservableCollection<string>();
                var time = new TimeSpan(09, 00, 00);
                while (time <= new TimeSpan(20, 00, 00))
                {
                    if (!recordedTimes.Contains(time))
                    {
                        quarterHourTimes.Add(time.ToString(@"hh\:mm\:ss"));
                    }
                    time = time.Add(new TimeSpan(0, 15, 0));
                }

                TimeCB.ItemsSource = quarterHourTimes;
            }
        }

        private void SpecializationCB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedSpec = (string)SpecializationCB.SelectedItem;
            var doctors = db.Doctor.Where(d => d.Specialization == selectedSpec).Select(d => d.Surname + " " + d.Name + " " + d.Middle_name).ToList();
            DoctorCB.ItemsSource = doctors;

        }

        private void SignupButton_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(mainWindow.PatientIdTextBox.Text, out int patientId))
            {
                if (DoctorCB.SelectedItem == null || DateCB.SelectedDate == null || TimeCB.SelectedItem == null)
                {
                    MessageBox.Show("Пожалуйста, выберите доктора, дату и время приема!", "Предупреждение",
                                    MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Получите выбранное имя врача из комбобокса
                var selectedDoctorName = (string)DoctorCB.SelectedItem;

                // Найдите объект Doctor, у которого ФИО совпадает с выбранным именем
                var selectedDoctor = db.Doctor.FirstOrDefault(d => (d.Surname + " " + d.Name + " " + d.Middle_name) == selectedDoctorName);
                var selectedDate = DateCB.SelectedDate.Value;
                var selectedTime = TimeSpan.Parse(TimeCB.SelectedItem.ToString());

                var patient = db.Patient.FirstOrDefault(p => p.ID == patientId);
                if (patient == null)
                {
                    MessageBox.Show("Пациент с указанным ID не найден!", "Предупреждение",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var medicalCard = db.Medical_card.FirstOrDefault(mc => mc.Medical_card_number == patient.Medical_card_number_id);
                if (medicalCard == null)
                {
                    MessageBox.Show("Медицинская карта для пациента с указанным ID не найдена!", "Предупреждение",
                                    MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                try
                {
                    // Проверяем, есть ли уже запись с такими же значениями даты, времени и врача
                    var existingRecord = db.Record.FirstOrDefault(r => r.Doctor_id == selectedDoctorId && DbFunctions.TruncateTime(r.Date_reception) == selectedDate.Date && r.Time_of_acceptance == selectedTime);
                    if (existingRecord != null)
                    {
                        MessageBox.Show("Вы уже записаны на прием!", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    var newRecord = new Record
                    {
                        ID = db.Record.Any() ? db.Record.Max(r => r.ID) + 1 : 1,
                        Medical_card_id = medicalCard.Medical_card_number,
                        Doctor_id = selectedDoctorId,
                        Date_reception = selectedDate,
                        Time_of_acceptance = selectedTime,
                        Status = "В"
                    };

                    db.Record.Add(newRecord);
                    db.SaveChanges();

                    var numTalon = db.Archive.Count(a => a.Patient_id == patientId && a.Archive_Type == "Талон") + 1;
                    var message = $"Номер талона: {numTalon}.\nДата приема: {selectedDate.ToString("dd.MM.yyyy")}\nВремя приема: {selectedTime.ToString()}.\nСпециализация врача: {selectedDoctor.Specialization}.\nФамилия врача: {selectedDoctor.Surname}.\nКабинет: {selectedDoctor.Cabinet}";
                    var maxArchivId = db.Archive.Any() ? db.Archive.Max(a => a.ID) + 1 : 1;
                    var newArchiv = new Archive
                    {
                        ID = maxArchivId,
                        Patient_id = patientId,
                        Archive_Type = "Талон",
                        Archive_Object = message
                    };

                    db.Archive.Add(newArchiv);
                    db.SaveChanges();
                    MessageBox.Show(message);
                    MessageBox.Show("Запись успешно создана и добавлена в архив!", "Успешно", MessageBoxButton.OK, MessageBoxImage.Information);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при бронировании приема: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}


