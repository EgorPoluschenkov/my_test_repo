﻿using NAST.Pag.PDateMedCard_TalonExport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using NAST.Pag.HospitalizationСontrol;

namespace NAST.Pag
{
    /// <summary>
    /// Логика взаимодействия для PageTEST.xaml
    /// </summary>
    public partial class PageTEST : Page
    {
        public PageTEST()
        {
            InitializeComponent();
        }
        private void Btn_Tour_Click(object sender, RoutedEventArgs e)
        {
            Manager.Fram.Navigate(new PageMED());
        }

        private void Btn_Employes_Click(object sender, RoutedEventArgs e)
        {
            Manager.Fram.Navigate(new PageTalon((MainWindow)Window.GetWindow(this)));
        }

        private void Btn_Hospitalization_Click(object sender, RoutedEventArgs e)
        {
            Manager.Fram.Navigate(new PageHospitalizationControl());
        }

    }
}
