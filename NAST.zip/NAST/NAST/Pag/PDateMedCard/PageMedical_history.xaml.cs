﻿using NAST.AddDate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NAST.Pag.PDateMedCard
{
    /// <summary>
    /// Логика взаимодействия для PageMedical_history.xaml
    /// </summary>
    public partial class PageMedical_history : Page
    {
        private Hospital1Entities1 db;
        List<PageMedical_historyViewModel> result;
        private MainWindow mainWindow;
        public PageMedical_history(MainWindow mainWindow)
        {
            InitializeComponent();
            db = new Hospital1Entities1();
            this.mainWindow = mainWindow;
            LoadData();
        }
        public class PageMedical_historyViewModel
        {
            public int PatientID { get; set; }
            public int DiagnosisID { get; set; }
            public string Diagnosis_name { get; set; }
            public DateTime Date_of_diagnosis { get; set; } // Изменен тип данных на DateTime
            public DateTime? End_dat { get; set; } // Изменен тип данных на DateTime
            public string The_course_of_the_disease { get; set; }
            public string ErrorMessage { get; set; }

        }
        public void LoadData()
        {
            if (int.TryParse(mainWindow.PatientIdTextBox.Text, out int patientId))
            {
                result = db.Database.SqlQuery<PageMedical_historyViewModel>($@"SELECT p.ID AS PatientID,
                                                                                    d.ID AS DiagnosisID,
                                                                                    d.Diagnosis_name,
                                                                                    d.Date_of_diagnosis,
                                                                                    d.End_dat,
                                                                                    d.The_course_of_the_disease
                                                                                    FROM Patient p
                                                                                    JOIN Patient_Diagnosis pd ON p.ID = pd.Patient_id
                                                                                    JOIN Diagnosis d ON pd.Diagnosis_id = d.ID
                                                                                    WHERE p.ID = {patientId}")
                                                                                    .ToList();

                // Проверка наличия данных в результате запроса
                if (result.Any())
                {
                    DGridTour.Visibility = Visibility.Visible;
                    BtnAdd.Visibility = Visibility.Visible;
                    BtnDelete.Visibility = Visibility.Visible;
                    BtnReset.Visibility = Visibility.Visible;
                    DGridTour.ItemsSource = result;

                    // Скрываем TextBlock
                    ErrorMessageTextBlock.Visibility = Visibility.Collapsed;
                }
                else
                {
                    // Если результат пуст, создайте экземпляр MedicalCardViewModel с сообщением об ошибке
                    result = new List<PageMedical_historyViewModel>
                    {
                        new PageMedical_historyViewModel
                        {
                            ErrorMessage = "Введите идентификатор"
                        }
                    };

                    DGridTour.Visibility = Visibility.Collapsed;
                    BtnAdd.Visibility = Visibility.Collapsed;
                    BtnDelete.Visibility = Visibility.Collapsed;
                    BtnReset.Visibility = Visibility.Collapsed;
                    DGridTour.ItemsSource = result;

                    // Отображаем TextBlock
                    ErrorMessageTextBlock.Visibility = Visibility.Visible;
                }
            }
            else
            {
                // Если patientId равен NULL, создайте экземпляр MedicalCardViewModel с сообщением об ошибке
                result = new List<PageMedical_historyViewModel>
                {
                    new PageMedical_historyViewModel
                    {
                        ErrorMessage = "Введите идентификатор"
                    }
                };

                DGridTour.Visibility = Visibility.Collapsed;
                DGridTour.ItemsSource = result;

                // Отображаем TextBlock
                ErrorMessageTextBlock.Visibility = Visibility.Visible;
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)//Редактирование
        {
            var selectedDiagnosis = (sender as Button).DataContext as PageMedical_historyViewModel;
            Manager.Fram.Navigate(new REDAK_PageMedical_history(selectedDiagnosis, selectedDiagnosis.PatientID));

        }


        private void BtnReset_Click(object sender, RoutedEventArgs e)//Обнавление
        {
            LoadData();
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)//Добавление
        {
            if (int.TryParse(mainWindow.PatientIdTextBox.Text, out int patientId))
            {
                Manager.Fram.Navigate(new ADD_PageMedical_history(null, patientId)); // Передаем значение patientId
            }
            else
            {
                MessageBox.Show("Введите корректный идентификатор пациента");
            }
        }
        private void BtnDelete_Click(object sender, RoutedEventArgs e)//Удаление
        {
            var selectedDiagnoses = DGridTour.SelectedItems.Cast<PageMedical_historyViewModel>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {selectedDiagnoses.Count()} элементов?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    foreach (var diagnosis in selectedDiagnoses)
                    {
                        // Удаляем запись из таблицы Diagnosis
                        var diagnosisToRemove = Hospital1Entities1.GetContext().Diagnosis.FirstOrDefault(d => d.ID == diagnosis.DiagnosisID);
                        if (diagnosisToRemove != null)
                        {
                            Hospital1Entities1.GetContext().Diagnosis.Remove(diagnosisToRemove);
                        }

                        // Удаляем соответствующую запись из таблицы Patient_Diagnosis
                        var patientDiagnosisToRemove = Hospital1Entities1.GetContext().Patient_Diagnosis.FirstOrDefault(pd => pd.Diagnosis_id == diagnosis.DiagnosisID);
                        if (patientDiagnosisToRemove != null)
                        {
                            Hospital1Entities1.GetContext().Patient_Diagnosis.Remove(patientDiagnosisToRemove);
                        }
                    }

                    Hospital1Entities1.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
        
        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                Hospital1Entities1.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridTour.ItemsSource = Hospital1Entities1.GetContext().Diagnosis.ToList();
            }
        }
    }
}