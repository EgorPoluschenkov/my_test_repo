﻿using NAST.AddDate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static NAST.Pag.PDateMedCard.PageMedical_history;


namespace NAST.Pag.PDateMedCard
{
    /// <summary>
    /// Логика взаимодействия для ADD_PageMedical_history.xaml
    /// </summary>
    public partial class ADD_PageMedical_history : Page
    {
        private Diagnosis _currentDiagnosis = new Diagnosis();
        public ADD_PageMedical_history(PageMedical_historyViewModel selectedDiagnosis, int patientId) // Добавляем параметр patientId
        {
            InitializeComponent();

            if (selectedDiagnosis != null)
                _currentDiagnosis = new Diagnosis
                {
                    ID = selectedDiagnosis.DiagnosisID,
                    Diagnosis_name = selectedDiagnosis.Diagnosis_name,
                    Date_of_diagnosis = selectedDiagnosis.Date_of_diagnosis,
                    End_dat = selectedDiagnosis.End_dat,
                    The_course_of_the_disease = selectedDiagnosis.The_course_of_the_disease
                };

            DataContext = _currentDiagnosis;

            // Присваиваем значение параметра patientId свойству PatientID
            PatientID = patientId;
        }

        // Добавляем свойство PatientID
        public int PatientID { get; set; }

        private void BtnSave_Click(object sender, RoutedEventArgs e) //Сохранение
        {
            StringBuilder errors = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentDiagnosis.Diagnosis_name))
                errors.AppendLine("Укажите Диагноз");
            if (_currentDiagnosis.Date_of_diagnosis == null)
                errors.AppendLine("Укажите Дату постановления");
            if (string.IsNullOrWhiteSpace(_currentDiagnosis.The_course_of_the_disease))
                errors.AppendLine("Укажите Положение");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }
            if (_currentDiagnosis.ID == 0)
            {
                var maxDiagnosisID = Hospital1Entities1.GetContext().Diagnosis.Max(d => d.ID);
                _currentDiagnosis.ID = maxDiagnosisID + 1;

                Hospital1Entities1.GetContext().Diagnosis.Add(_currentDiagnosis);
                
            }

            if (_currentDiagnosis.End_dat == null)
            {
                _currentDiagnosis.End_dat = null;
                
            }

            try
            {
                Hospital1Entities1.GetContext().SaveChanges();

                Patient_Diagnosis patient_Diagnosis = new Patient_Diagnosis
                {
                    ID = _currentDiagnosis.ID,
                    Patient_id = PatientID,
                    Diagnosis_id = _currentDiagnosis.ID
                };
                Hospital1Entities1.GetContext().Patient_Diagnosis.Add(patient_Diagnosis);
                Hospital1Entities1.GetContext().SaveChanges();

                Manager.Fram.GoBack();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

            // Обновляем данные в DataGrid на странице PageMedical_history
            if (Manager.Fram.Content is PageMedical_history pageMedicalHistory)
            {
               
                pageMedicalHistory.LoadData();
            }
            
        }
    }
}
