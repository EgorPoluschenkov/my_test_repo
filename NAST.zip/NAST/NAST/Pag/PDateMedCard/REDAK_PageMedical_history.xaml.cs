﻿using NAST.AddDate;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static NAST.Pag.PDateMedCard.PageMedical_history;

namespace NAST.Pag.PDateMedCard
{
    /// <summary>
    /// Логика взаимодействия для REDAK_PageMedical_history.xaml
    /// </summary>
    public partial class REDAK_PageMedical_history : Page
    {
        private Diagnosis _currentDiagnosis = new Diagnosis();
        public REDAK_PageMedical_history(PageMedical_historyViewModel selectedDiagnosis, int patientId) // Добавляем параметр patientId
        {
            InitializeComponent();

            if (selectedDiagnosis != null)
                _currentDiagnosis = new Diagnosis
                {
                    ID = selectedDiagnosis.DiagnosisID,
                    Diagnosis_name = selectedDiagnosis.Diagnosis_name,
                    Date_of_diagnosis = selectedDiagnosis.Date_of_diagnosis,
                    End_dat = selectedDiagnosis.End_dat,
                    The_course_of_the_disease = selectedDiagnosis.The_course_of_the_disease
                };

            DataContext = _currentDiagnosis;

            // Присваиваем значение параметра patientId свойству PatientID
            PatientID = patientId;
        }

        // Добавляем свойство PatientID
        public int PatientID { get; set; }

        private void BtnSave_Click(object sender, RoutedEventArgs e) //Сохранение
        {
            StringBuilder errors = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentDiagnosis.Diagnosis_name))
                errors.AppendLine("Укажите Диагноз");
            if (_currentDiagnosis.Date_of_diagnosis == null)
                errors.AppendLine("Укажите Дату постановления");
            if (string.IsNullOrWhiteSpace(_currentDiagnosis.The_course_of_the_disease))
                errors.AppendLine("Укажите Положение");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            try
            {
                using (var context = new Hospital1Entities1())
                {
                    if (_currentDiagnosis.ID == 0)
                    {
                        // Генерируем новый ID для диагноза
                        int maxDiagnosisID = context.Diagnosis.Max(d => d.ID);
                        _currentDiagnosis.ID = maxDiagnosisID + 1;

                        // Добавляем новую запись в таблицу Diagnosis
                        context.Diagnosis.Add(_currentDiagnosis);
                    }
                    else
                    {
                        // Находим соответствующую запись в таблице Diagnosis и обновляем ее значения
                        var diagnosisToUpdate = context.Diagnosis.FirstOrDefault(d => d.ID == _currentDiagnosis.ID);
                        if (diagnosisToUpdate != null)
                        {
                            diagnosisToUpdate.Diagnosis_name = _currentDiagnosis.Diagnosis_name;
                            diagnosisToUpdate.Date_of_diagnosis = _currentDiagnosis.Date_of_diagnosis;
                            diagnosisToUpdate.End_dat = _currentDiagnosis.End_dat;
                            diagnosisToUpdate.The_course_of_the_disease = _currentDiagnosis.The_course_of_the_disease;
                        }
                        context.SaveChanges();
                        MessageBox.Show("Операция завершена успешно");
                        Manager.Fram.GoBack();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

            // Обновляем данные в DataGrid на странице PageMedical_history
            if (Manager.Fram.Content is PageMedical_history pageMedicalHistory)
            {
                pageMedicalHistory.LoadData();
            }
        }
    }
}