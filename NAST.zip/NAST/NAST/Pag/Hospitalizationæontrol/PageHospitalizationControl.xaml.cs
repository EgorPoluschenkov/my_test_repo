﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NAST.AddDate;
using System.Data.SqlClient;

namespace NAST.Pag.HospitalizationСontrol
{
    public partial class PageHospitalizationControl : Page
    {
        private const string ConnectionString = "Your_Connection_String_Here";

        public PageHospitalizationControl()
        {
            InitializeComponent();
            DisplayRoomsAndBeds();
        }

        private void DisplayRoomsAndBeds()
        {
            // Initialize room numbers and bed counts
            Dictionary<int, int> roomsAndBeds = new Dictionary<int, int>
{
    { 101, 5 },
    { 102, 5 },
    { 103, 5 },
    { 104, 5 }, 
    { 105, 4 },
    { 106, 4 }, 
    { 107, 4 }, 
    { 108, 3 },
    { 109, 3 },
    { 110, 3 },
    { 111, 4 },
    { 112, 4 }, 
    { 113, 4 }, 
    { 114, 4 },
    { 115, 4 }, 
    { 116, 5 },
    { 117, 5 },
    { 118, 5 }
};

            // Create SQL connection
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                SqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT Room_number, Bed_number FROM Hospitalizations";

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string roomNumber = reader["Room_number"].ToString();
                        string bedNumber = reader["Bed_number"].ToString();

                        // Find corresponding label
                        Label label = FindLabelByRoomAndBed(roomNumber, bedNumber);
                        if (label != null)
                        {
                            label.Background = Brushes.Red; // Set background color to red if bed is occupied
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private Label FindLabelByRoomAndBed(string roomNumber, string bedNumber)
        {
            string labelName = $"{roomNumber}.{bedNumber}";
            return (Label)FindName(labelName);
        }
    }
}