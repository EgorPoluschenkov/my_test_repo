﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace NAST.Pag
{
    /// <summary>
    /// Логика взаимодействия для PageLogin.xaml
    /// </summary>
    public partial class PageLogin : Page
    {
        public PageLogin()
        {
            InitializeComponent();
        }

        private void Btn_login_Click(object sender, RoutedEventArgs e)
        {
            var CurrentUser = AppDate1.Sqlconn.Access.FirstOrDefault(p => p.Login == TextLg.Text && p.Passwoed == TextPass.Text);

            if (CurrentUser != null)
            {
                if (CurrentUser.Patient_id.HasValue || CurrentUser.Stuff_id.HasValue)
                {
                    MessageBox.Show("Вход в систему запрещен", "Уведомление");
                }
                else
                {
                    string fullName = GetDoctorFullName(CurrentUser.Doctor_id);
                    MessageBox.Show($"Добро пожаловать {fullName} в систему", "Уведомление");
                    Manager.Fram.Navigate(new PageTEST());
                }
            }
            else
            {
                MessageBox.Show("Данного пользователя не существует");
            }
        }

        private string GetDoctorFullName(int? doctorId)
        {
            if (doctorId.HasValue)
            {
                var doctor = AppDate1.Sqlconn.Doctor.FirstOrDefault(d => d.ID == doctorId.Value);
                if (doctor != null)
                {
                    return $"{doctor.Name} {doctor.Middle_name}";
                }
            }
            return string.Empty;
        }
    }
}
